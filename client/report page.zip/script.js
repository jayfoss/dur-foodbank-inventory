$(document).ready(function(){
    
    
});

function toggleSidebar(){
    document.getElementById("nav").classList.toggle("nav-active");
    document.getElementById("main").classList.toggle("main-active");
    document.getElementById("hamburger-bars").classList.toggle("hamburger-active");
}